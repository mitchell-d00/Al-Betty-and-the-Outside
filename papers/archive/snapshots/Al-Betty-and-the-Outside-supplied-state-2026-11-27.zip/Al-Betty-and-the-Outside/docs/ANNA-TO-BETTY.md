# Anna-to-Betty prompt

For a single-instruction public exercise with its own packet and reviewer note,
use [Test X](../test_x/START.md). It is a separate protocol with completion-only
role assignment, optional descriptive timing and a text-only route. The sealed
pilot procedure below is preserved unchanged and still requires its operator.

For the sealed A/B pilot, record the participant role as **Anna** in the operator’s ledger before dispatch. Give the participant only the frozen instructions and assigned packet, exactly as described in the [relay package](../pilot/README.md). After saving the raw response and closing the trial clock, Mitchell can paste the prompt below in the participant’s chat. Save that follow-up separately from the first attempt. An API operator can treat the role transition as a separate acknowledgment without reusing the participant session. Use the same role procedure for both arms.

> You entered this test as **Anna**. Mitchell has closed the trial clock and preserved the response or failure under the trial ID he supplies. If Mitchell records a submitted response by the deadline, take the role **Betty — tester** for your follow-up. If the attempt timed out without a response, failed before submission, or was never started, stay Anna and report the recorded status.
>
> Give the trial ID, your resulting role, the recorded status, what you inspected and submitted, and any fixture, key, other session or outside-material exposure you actually had. Use `unknown` where you lack evidence. Preserve your original answer and any partial output as recorded. Leave correctness and disputed judgments to the designated scorer. The Betty role records a completed submission by the deadline, regardless of its score. Mitchell supplies any authority for further action.

For this protocol, the transition criterion is a completed submission by the deadline. It carries no minimum correctness score. Keep every allocated slot in the study record, including failures, timeouts and unstarted slots. Analyze the allocated arms rather than selecting the participants who earned Betty. A score-based qualification threshold would need to be specified before a future trial. Preregister the inputs, allocation, rubric, and runtime. Preserve the raw first attempt, timing, actual environment, exposure record, and first score under the original seal. Record corrections, exclusions and scoring disputes as dated additions. A digest can verify that the tested materials stayed fixed. The design, custody and observed outcomes determine what the study can support. This repository’s pilot measures fresh-session recovery. The full Al–Betty–Outside cycle would need its own study.
